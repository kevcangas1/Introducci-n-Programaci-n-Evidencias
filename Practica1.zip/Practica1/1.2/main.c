#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
  float pies,centimetros,pulgadas,yardas,metros;
  
  printf("Programa de conversion de Pies a pulgadas,yardas,centimetros y metros\n");
  
  printf("\nIntroduzca el valor:");
  
  scanf("%f",&pies);
  
  pulgadas=pies*12;
  yardas=pies/3;
  centimetros=pulgadas*2.54;
  metros=centimetros/100;
  
  printf("\nPulgadas:%3.2f\n",pulgadas);
  printf("\nYardas:%3.2f\n",yardas);
  printf("\nCentimetros:%3.2f\n",centimetros);
  printf("\nMetros:%f3.2\n\n",metros);
  
  system("PAUSE");	
  return 0;
}
