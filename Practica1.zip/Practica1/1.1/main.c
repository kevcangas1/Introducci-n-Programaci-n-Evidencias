#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
  float x,y,a,b,res;
  a=0;
  b=0;
  y=0;
  x=0;
  
  printf("Programa de solucion de la operacion (x+y)^2(a-b)\n");
  
  printf("\nIntroduzca a:");
  scanf("%f",&a);
  printf("\nIntroduzca b:");
  scanf("%f",&b);
  printf("\nIntroduzca x:");
  scanf("%f",&x); 
  printf("\nIntroduzca y:");
  scanf("%f",&y);
  
  
  res=(x+y)*(x+y)*(a-b);
  
  printf("\nResultado:%5.1f\n",res);         
  
  system("PAUSE");	
  return 0;
}
