#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
  int segundos,minutos,horas,st;
  
  printf("Programa para calcular horas, minutos y segundos\n");
  
  printf("Segundos totales:");
  scanf("%d",&st);
  
 horas= (st/60>=60) ? st/60/60:0;
 minutos= (st/60<60) ? st/60:(st-(3600*horas))/60;
 segundos= (st/60<60) ? st%60:(st-(3600*horas))%60;
 
    
  printf("Horas:%d\n",horas); 
  printf("Minutos:%d\n",minutos); 
  printf("Segundos:%d\n",segundos); 
  
  system("PAUSE");	
  return 0;
}
