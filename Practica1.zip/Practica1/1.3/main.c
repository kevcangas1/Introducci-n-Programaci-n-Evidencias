#include <stdio.h>
#include <stdlib.h>
#define PI 3.1416
#include <math.h>

int main(int argc, char *argv[])
{
  float area,volumen,radio,altura,lado;
  printf("Programa para calcular el volumen y el area de un cono\n",radio);
  
  printf("\nIntroduzca el radio:",radio);
  scanf("%f",&radio);
  
  printf("\nIntroduzca el altura:",altura);
  scanf("%f",&altura);
  
  lado=sqrt((radio*radio)+(altura*altura));
  
  area=(2*PI*radio*(lado/2))+(PI*radio*radio);
  printf("\nArea:%f\n\n",area);
  
  volumen=(PI*radio*radio*altura)/3;
  printf("Volumen:%f\n\n",volumen);
  
  
  
  
  
  
  system("PAUSE");	
  return 0;


}
